# ✈️ AM4 Fuel Alert — PWA para Android

## Como instalar no Android (sem APK, sem Play Store)

### Opção A — Hospedar de graça no GitHub Pages

1. Crie uma conta gratuita em https://github.com
2. Clique em **"New repository"** → nome: `am4-alert` → marque **Public**
3. Faça upload de todos os arquivos desta pasta
4. Vá em **Settings → Pages → Source: main → /root** e salve
5. Seu app estará em: `https://SEU_USUARIO.github.io/am4-alert/`

### Opção B — Hospedar de graça no Netlify (mais fácil)

1. Acesse https://netlify.com e faça login com GitHub
2. Arraste a pasta `am4-pwa` para o site do Netlify
3. Pronto! Em 30 segundos você tem uma URL como `https://am4-alert.netlify.app`

---

## Instalar no Android (Chrome)

1. Acesse a URL do seu app no Chrome para Android
2. Chrome vai mostrar um banner automático "Adicionar à tela inicial"
3. OU: toque no menu ⋮ → **"Instalar aplicativo"** ou **"Adicionar à tela inicial"**
4. Confirme — o ícone aparece na tela inicial igual a um app nativo!

> O app funciona offline, mostra na barra de apps, sem barra do navegador.

---

## Funcionalidades do App

- ⛽ **Preço em tempo real** do Combustível e CO2
- 🔔 **Notificações** quando os preços ficarem baratos
- ⏱️ **Countdown** para a próxima mudança de preço (a cada 30 min)
- 📊 **Histórico** das últimas verificações
- ⚙️ **Limites configuráveis** (padrão: Fuel < $600, CO2 < $150)
- 🔄 **Auto-verificação** a cada 30 minutos em segundo plano
- 📲 **Offline** — funciona sem internet após o primeiro acesso

---

## Estrutura dos Arquivos

```
am4-pwa/
├── index.html      ← App principal (toda a lógica)
├── manifest.json   ← Configuração do PWA (nome, ícone, cor)
├── sw.js           ← Service Worker (offline + notificações push)
└── icons/
    ├── icon-192.png
    └── icon-512.png
```
